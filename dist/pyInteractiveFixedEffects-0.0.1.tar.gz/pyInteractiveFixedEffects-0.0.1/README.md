# Panel Data Models with Interactive Fixed Effects
*Python implementation by [Javier Boncompte](mailto:javier.boncompte.19@ucl.ac.uk) of the **Interactive Fixed Effects Model** for panel data presented in [Bai (2009)](https://onlinelibrary.wiley.com/doi/abs/10.3982/ECTA6135).*

